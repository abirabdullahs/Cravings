import { Link } from "react-router-dom";
import { MapPin, Search, ShoppingBag } from "lucide-react";
import { useCart } from "@/context/CartContext";

interface HeaderProps {
  searchDefaultValue?: string;
  searchPlaceholder?: string;
}

export default function Header({
  searchDefaultValue = "",
  searchPlaceholder = "Search restaurants, cuisines...",
}: HeaderProps) {
  const { count } = useCart();

  return (
    <header className="border-b border-border bg-background">
      <div className="flex flex-col gap-4 px-4 py-4 sm:px-6 md:flex-row md:items-center md:justify-between md:gap-6 md:px-10 lg:px-20 lg:py-6">
        <div className="flex items-center justify-between gap-4 md:justify-start md:gap-12">
          <Link
            to="/"
            className="font-serif text-2xl font-black text-primary lg:text-[32px]"
          >
            Cravings.
          </Link>
          <div className="hidden items-center gap-2 rounded-sm border border-primary bg-white px-3.5 py-2 sm:flex">
            <MapPin className="h-3.5 w-3.5 shrink-0 text-primary" strokeWidth={2} />
            <span className="font-sans text-[13px] font-semibold text-foreground">
              Dhaka
            </span>
          </div>
          <div className="flex items-center gap-6 md:hidden">
            <Link
              to="/cart"
              className="flex items-center gap-1.5 font-sans text-sm font-semibold text-foreground"
            >
              <ShoppingBag className="h-[18px] w-[18px]" strokeWidth={2} />
              <span>Cart ({count})</span>
            </Link>
          </div>
        </div>

        <label className="flex w-full items-center gap-3 rounded-sm border border-border bg-white px-4 py-3 md:max-w-[420px]">
          <Search className="h-4 w-4 shrink-0 text-primary" strokeWidth={2} />
          <input
            type="text"
            defaultValue={searchDefaultValue}
            placeholder={searchPlaceholder}
            className="w-full bg-transparent font-sans text-sm font-semibold text-foreground placeholder:text-muted-foreground placeholder:font-medium focus:outline-none"
          />
        </label>

        <div className="hidden items-center gap-8 md:flex">
          <Link
            to="/cart"
            className="flex items-center gap-2 font-sans text-sm font-semibold text-foreground transition-colors hover:text-primary"
          >
            <ShoppingBag className="h-[18px] w-[18px]" strokeWidth={2} />
            <span>Cart ({count})</span>
          </Link>
          <Link
            to="/login"
            className="font-sans text-sm font-semibold text-foreground transition-colors hover:text-primary"
          >
            Login
          </Link>
        </div>
      </div>
    </header>
  );
}
