import { ReactNode } from "react";
import Header from "./Header";
import Footer from "./Footer";

interface LayoutProps {
  children: ReactNode;
  searchDefaultValue?: string;
  searchPlaceholder?: string;
}

export default function Layout({
  children,
  searchDefaultValue,
  searchPlaceholder,
}: LayoutProps) {
  return (
    <div className="flex min-h-screen flex-col bg-background">
      <Header
        searchDefaultValue={searchDefaultValue}
        searchPlaceholder={searchPlaceholder}
      />
      <main className="flex-1">{children}</main>
      <Footer />
    </div>
  );
}
