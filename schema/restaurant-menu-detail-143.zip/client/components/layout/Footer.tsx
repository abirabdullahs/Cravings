import { Link } from "react-router-dom";

const exploreLinks = [
  { label: "Our Selection", to: "/" },
  { label: "Dhakaiya Heritage", to: "/" },
  { label: "The Edit", to: "/" },
];

const supportLinks = [
  { label: "Contact Curators", to: "/support" },
  { label: "Delivery Areas", to: "/support" },
  { label: "Merchant Partners", to: "/support" },
];

export default function Footer() {
  return (
    <footer className="bg-foreground text-white">
      <div className="flex flex-col gap-10 px-4 py-14 sm:px-6 md:flex-row md:justify-between md:px-10 lg:px-20 lg:py-16">
        <div className="max-w-sm">
          <span className="font-serif text-2xl font-black text-primary">
            Cravings.
          </span>
          <p className="mt-3 font-sans text-sm text-white/60">
            Fine-dining delivery, celebrating the historic and modern
            culinary heritage of Dhaka.
          </p>
        </div>

        <div className="flex gap-12 sm:gap-20">
          <div>
            <h3 className="font-sans text-xs font-bold uppercase tracking-wide text-primary">
              Explore
            </h3>
            <ul className="mt-4 flex flex-col gap-3">
              {exploreLinks.map((link) => (
                <li key={link.label}>
                  <Link
                    to={link.to}
                    className="font-sans text-sm text-white/70 transition-colors hover:text-white"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <h3 className="font-sans text-xs font-bold uppercase tracking-wide text-primary">
              Support
            </h3>
            <ul className="mt-4 flex flex-col gap-3">
              {supportLinks.map((link) => (
                <li key={link.label}>
                  <Link
                    to={link.to}
                    className="font-sans text-sm text-white/70 transition-colors hover:text-white"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>

      <div className="flex flex-col gap-2 border-t border-white/10 px-4 py-6 sm:px-6 sm:flex-row sm:items-center sm:justify-between md:px-10 lg:px-20">
        <p className="font-sans text-xs text-white/50">
          © 2026 Cravings Delivery. All rights reserved.
        </p>
        <p className="font-sans text-xs text-white/50">Dhaka, Bangladesh</p>
      </div>
    </footer>
  );
}
