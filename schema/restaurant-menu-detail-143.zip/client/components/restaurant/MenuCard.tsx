import { MenuItem } from "@/data/restaurants";

interface MenuCardProps {
  item: MenuItem;
  onAdd: (item: MenuItem) => void;
}

export default function MenuCard({ item, onAdd }: MenuCardProps) {
  return (
    <div className="flex flex-col overflow-hidden rounded border border-border bg-white">
      <img
        src={item.image}
        alt={item.name}
        className="h-[220px] w-full object-cover"
      />
      <div className="flex flex-1 flex-col gap-2 p-5">
        <h3 className="font-serif text-xl font-semibold text-foreground">
          {item.name}
        </h3>
        <p className="line-clamp-3 font-sans text-[13px] leading-5 text-muted-foreground">
          {item.description}
        </p>
      </div>
      <div className="flex items-center justify-between border-t border-border bg-muted px-5 py-3.5">
        <span className="font-sans text-base font-bold text-foreground">
          ৳{item.price}
        </span>
        <button
          onClick={() => onAdd(item)}
          className="rounded-sm bg-primary px-4 py-2 font-sans text-[13px] font-bold text-primary-foreground transition-opacity hover:opacity-90"
        >
          Add to Cart
        </button>
      </div>
    </div>
  );
}
