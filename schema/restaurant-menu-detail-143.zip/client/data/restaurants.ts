export interface MenuItem {
  id: string;
  name: string;
  description: string;
  price: number;
  category: string;
  image: string;
}

export interface Restaurant {
  slug: string;
  name: string;
  badge: string;
  rating: number;
  reviewCount: number;
  tags: string;
  description: string;
  deliveryTime: string;
  minOrder: number;
  deliveryFee: number;
  heroImage: string;
  cardImage: string;
  categories: string[];
  menu: MenuItem[];
}

export const restaurants: Restaurant[] = [
  {
    slug: "sultans-dine",
    name: "Sultan's Dine",
    badge: "Royal Feast",
    rating: 4.8,
    reviewCount: 500,
    tags: "Kacchi • Biryani • Traditional",
    description:
      "Sultan's Dine is Dhaka's most celebrated destination for authentic Kacchi Biryani. Established with a philosophy of serving royalty-grade feasts, we slow-cook our premium basmati rice and farm-fresh meat over wood fires in copper handis. A historic recipe crafted to perfection since 1986.",
    deliveryTime: "45 mins delivery",
    minOrder: 300,
    deliveryFee: 50,
    heroImage:
      "https://api.builder.io/api/v1/image/assets/TEMP/c8f87af53fbd9b63bcbd3251bb866b1c8a114147?width=1200",
    cardImage:
      "https://api.builder.io/api/v1/image/assets/TEMP/6c30b1663932cc5976f21b42790b4fb472ce3068?width=821",
    categories: ["Kacchi", "Biryani", "Sides", "Drinks", "Desserts"],
    menu: [
      {
        id: "kacchi-biryani",
        name: "Sultan's Special Kacchi Biryani",
        description:
          "Premium mutton chunks layered with fragrant basmati, fried potato, and a hard-boiled egg, slow-cooked in copper handis.",
        price: 350,
        category: "Kacchi",
        image:
          "https://api.builder.io/api/v1/image/assets/TEMP/6c30b1663932cc5976f21b42790b4fb472ce3068?width=821",
      },
      {
        id: "mutton-tehari",
        name: "Dhakaiya Mutton Tehari",
        description:
          "Aromatic chinigura rice cooked in pure mustard oil with succulent, small-cut mutton pieces infused with green chilis.",
        price: 250,
        category: "Biryani",
        image:
          "https://api.builder.io/api/v1/image/assets/TEMP/af2e1413fadc49e64c9276d1e68ee1251c38b0e9?width=821",
      },
      {
        id: "shahi-chicken-biryani",
        name: "Shahi Chicken Biryani",
        description:
          "Richly seasoned chicken quarter roast layered between aromatic basmati rice, served with a classic boiled egg.",
        price: 280,
        category: "Biryani",
        image:
          "https://images.unsplash.com/photo-1633945274405-b6c8069047b0?w=800&q=80",
      },
      {
        id: "shahi-firni",
        name: "Shahi Firni",
        description:
          "Traditional sweet rice pudding slow-brewed in thick cream and aromatic saffron, topped with rich crushed pistachios.",
        price: 80,
        category: "Desserts",
        image:
          "https://images.unsplash.com/photo-1615887023544-9f5a0cef2c99?w=800&q=80",
      },
      {
        id: "dhakaiya-borhani",
        name: "Dhakaiya Borhani",
        description:
          "Dhaka's signature spiced yogurt drink blended with mint, coriander, mustard, cumin, and a kick of green chili.",
        price: 60,
        category: "Drinks",
        image:
          "https://images.unsplash.com/photo-1601050690597-df0568f70950?w=800&q=80",
      },
      {
        id: "mutton-jali-kabab",
        name: "Spiced Mutton Jali Kabab",
        description:
          "Finely minced mutton patty infused with traditional heritage spices, dipped in whipped egg yolk and deep fried to a crispy lacy finish.",
        price: 320,
        category: "Sides",
        image:
          "https://images.unsplash.com/photo-1626082927389-6cd097cee6a6?w=800&q=80",
      },
    ],
  },
];

export function getRestaurantBySlug(slug: string) {
  return restaurants.find((r) => r.slug === slug);
}
