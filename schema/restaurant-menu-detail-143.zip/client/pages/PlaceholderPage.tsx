import { Link } from "react-router-dom";
import Layout from "@/components/layout/Layout";

interface PlaceholderPageProps {
  title: string;
  description?: string;
}

export default function PlaceholderPage({
  title,
  description = "This page hasn't been built yet. Keep prompting to describe what you'd like here and it will come to life.",
}: PlaceholderPageProps) {
  return (
    <Layout>
      <div className="flex min-h-[60vh] flex-col items-center justify-center gap-4 px-6 py-24 text-center">
        <h1 className="font-serif text-3xl font-bold text-foreground">
          {title}
        </h1>
        <p className="max-w-md font-sans text-sm text-muted-foreground">
          {description}
        </p>
        <Link
          to="/"
          className="mt-2 rounded-sm bg-primary px-5 py-2.5 font-sans text-sm font-bold text-primary-foreground transition-opacity hover:opacity-90"
        >
          Back to home
        </Link>
      </div>
    </Layout>
  );
}
