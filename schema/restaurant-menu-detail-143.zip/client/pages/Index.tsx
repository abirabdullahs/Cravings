import { Link } from "react-router-dom";
import { Clock, Star } from "lucide-react";
import Layout from "@/components/layout/Layout";
import { restaurants } from "@/data/restaurants";

export default function Index() {
  return (
    <Layout>
      <section className="border-b border-border bg-white px-4 py-16 sm:px-6 md:px-10 lg:px-20 lg:py-24">
        <div className="mx-auto flex max-w-3xl flex-col items-center gap-5 text-center">
          <span className="rounded-sm border border-primary bg-secondary px-3 py-1.5 font-sans text-[11px] font-bold uppercase tracking-wide text-primary">
            Now delivering across Dhaka
          </span>
          <h1 className="font-serif text-4xl font-black leading-tight text-foreground sm:text-5xl lg:text-6xl">
            Dhaka's finest kitchens,
            <br />
            delivered to your door.
          </h1>
          <p className="max-w-xl font-sans text-base leading-7 text-muted-foreground">
            Cravings curates the city's most celebrated restaurants,
            preserving historic recipes and modern fine-dining, one order at
            a time.
          </p>
        </div>
      </section>

      <section className="flex flex-col gap-8 px-4 py-14 sm:px-6 md:px-10 lg:px-20 lg:py-20">
        <div className="flex flex-col gap-2">
          <h2 className="font-serif text-2xl font-semibold text-foreground sm:text-[28px]">
            Featured Restaurants
          </h2>
          <p className="font-sans text-sm font-medium text-muted-foreground">
            Showing {restaurants.length} celebrated kitchen
            {restaurants.length === 1 ? "" : "s"} near you
          </p>
        </div>

        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {restaurants.map((restaurant) => (
            <Link
              key={restaurant.slug}
              to={`/restaurant/${restaurant.slug}`}
              className="group flex flex-col overflow-hidden rounded border border-border bg-white transition-shadow hover:shadow-md"
            >
              <img
                src={restaurant.cardImage}
                alt={restaurant.name}
                className="h-[220px] w-full object-cover"
              />
              <div className="flex flex-1 flex-col gap-2 p-5">
                <div className="flex items-center justify-between gap-2">
                  <span className="rounded-sm border border-primary bg-secondary px-2.5 py-1 font-sans text-[10px] font-bold uppercase tracking-wide text-primary">
                    {restaurant.badge}
                  </span>
                  <div className="flex items-center gap-1">
                    <span className="font-serif text-sm font-bold italic text-primary">
                      {restaurant.rating}
                    </span>
                    <Star
                      className="h-3 w-3 fill-primary text-primary"
                      strokeWidth={2}
                    />
                  </div>
                </div>
                <h3 className="font-serif text-xl font-semibold text-foreground group-hover:text-primary">
                  {restaurant.name}
                </h3>
                <p className="font-sans text-[13px] font-semibold uppercase tracking-wide text-primary">
                  {restaurant.tags}
                </p>
              </div>
              <div className="flex items-center justify-between border-t border-border bg-muted px-5 py-3.5">
                <div className="flex items-center gap-1.5">
                  <Clock className="h-3.5 w-3.5 text-muted-foreground" strokeWidth={2} />
                  <span className="font-sans text-xs font-semibold text-foreground">
                    {restaurant.deliveryTime}
                  </span>
                </div>
                <span className="font-sans text-xs text-muted-foreground">
                  Min. ৳{restaurant.minOrder}
                </span>
              </div>
            </Link>
          ))}
        </div>
      </section>
    </Layout>
  );
}
