import { useMemo, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { Clock, Search, Star } from "lucide-react";
import Layout from "@/components/layout/Layout";
import MenuCard from "@/components/restaurant/MenuCard";
import { getRestaurantBySlug, MenuItem } from "@/data/restaurants";
import { useCart } from "@/context/CartContext";
import { useToast } from "@/hooks/use-toast";
import PlaceholderPage from "./PlaceholderPage";

export default function RestaurantDetail() {
  const { slug } = useParams();
  const restaurant = slug ? getRestaurantBySlug(slug) : undefined;
  const { addItem } = useCart();
  const { toast } = useToast();
  const [activeCategory, setActiveCategory] = useState("All");
  const [query, setQuery] = useState("");

  const groupedMenu = useMemo(() => {
    if (!restaurant) return [];
    const normalizedQuery = query.trim().toLowerCase();
    const categories =
      activeCategory === "All" ? restaurant.categories : [activeCategory];

    return categories
      .map((category) => ({
        category,
        items: restaurant.menu.filter(
          (item) =>
            item.category === category &&
            item.name.toLowerCase().includes(normalizedQuery),
        ),
      }))
      .filter((group) => group.items.length > 0);
  }, [restaurant, activeCategory, query]);

  const visibleCount = groupedMenu.reduce(
    (sum, group) => sum + group.items.length,
    0,
  );

  if (!restaurant) {
    return <PlaceholderPage title="Restaurant not found" />;
  }

  const handleAdd = (item: MenuItem) => {
    addItem({ id: item.id, name: item.name, price: item.price });
    toast({ title: "Added to cart", description: item.name });
  };

  return (
    <Layout searchDefaultValue={restaurant.name}>
      <nav className="flex items-center gap-2 px-4 pt-6 pb-3 sm:px-6 md:px-10 lg:px-20">
        <Link
          to="/"
          className="font-sans text-[13px] font-medium text-muted-foreground hover:text-foreground"
        >
          Home
        </Link>
        <span className="font-sans text-[13px] font-medium text-muted-foreground/70">
          /
        </span>
        <Link
          to="/"
          className="font-sans text-[13px] font-medium text-muted-foreground hover:text-foreground"
        >
          Restaurants
        </Link>
        <span className="font-sans text-[13px] font-medium text-muted-foreground/70">
          /
        </span>
        <span className="font-sans text-[13px] font-bold text-primary">
          {restaurant.name}
        </span>
      </nav>

      <section className="px-4 pb-12 pt-3 sm:px-6 md:px-10 lg:px-20">
        <div className="flex flex-col overflow-hidden rounded border border-border bg-white lg:flex-row">
          <div className="flex flex-1 flex-col gap-6 p-6 sm:p-8 lg:p-12">
            <div className="flex flex-col gap-3">
              <div className="flex flex-wrap items-center gap-2">
                <span className="rounded-sm border border-primary bg-secondary px-3 py-1.5 font-sans text-[11px] font-bold uppercase tracking-wide text-primary">
                  {restaurant.badge}
                </span>
                <div className="flex items-center gap-1.5">
                  <span className="font-serif text-lg font-bold italic text-primary">
                    {restaurant.rating}
                  </span>
                  <Star
                    className="h-3.5 w-3.5 fill-primary text-primary"
                    strokeWidth={2}
                  />
                  <span className="font-sans text-xs font-medium text-muted-foreground">
                    ({restaurant.reviewCount}+ ratings)
                  </span>
                </div>
              </div>
              <h1 className="font-serif text-4xl font-black text-foreground sm:text-5xl">
                {restaurant.name}
              </h1>
              <p className="font-sans text-sm font-semibold uppercase tracking-wide text-primary">
                {restaurant.tags}
              </p>
            </div>

            <p className="max-w-xl font-sans text-[15px] leading-6 text-muted-foreground">
              {restaurant.description}
            </p>

            <div className="h-px w-full max-w-xl bg-border" />

            <div className="flex flex-wrap items-center gap-6 sm:gap-10">
              <div className="flex items-center gap-2">
                <Clock className="h-4 w-4 text-muted-foreground" strokeWidth={2} />
                <span className="font-sans text-sm font-semibold text-foreground">
                  {restaurant.deliveryTime}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <span className="font-sans text-sm text-muted-foreground">
                  Min. order
                </span>
                <span className="font-sans text-sm font-bold text-foreground">
                  ৳{restaurant.minOrder}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <span className="font-sans text-sm text-muted-foreground">
                  Delivery Fee
                </span>
                <span className="font-sans text-sm font-bold text-foreground">
                  ৳{restaurant.deliveryFee}
                </span>
              </div>
            </div>
          </div>
          <img
            src={restaurant.heroImage}
            alt={restaurant.name}
            className="h-64 w-full object-cover lg:h-auto lg:w-[600px]"
          />
        </div>
      </section>

      <div className="flex flex-col gap-4 border-y border-border bg-muted px-4 py-5 sm:px-6 md:flex-row md:items-center md:justify-between md:px-10 lg:px-20">
        <div className="flex flex-wrap items-center gap-2">
          {["All", ...restaurant.categories].map((category) => (
            <button
              key={category}
              onClick={() => setActiveCategory(category)}
              className={`rounded px-5 py-3 font-sans text-sm transition-colors ${
                activeCategory === category
                  ? "border border-primary bg-secondary font-bold text-primary"
                  : "border border-border bg-white font-medium text-foreground hover:border-primary/50"
              }`}
            >
              {category}
            </button>
          ))}
        </div>
        <label className="flex w-full items-center gap-2.5 rounded border border-border bg-white px-4 py-3 md:w-64">
          <Search className="h-3.5 w-3.5 shrink-0 text-muted-foreground" strokeWidth={2} />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search in this menu..."
            className="w-full bg-transparent font-sans text-[13px] text-foreground placeholder:text-muted-foreground focus:outline-none"
          />
        </label>
      </div>

      <section className="flex flex-col gap-10 px-4 py-12 sm:px-6 md:px-10 lg:px-20 lg:py-16">
        <div className="flex flex-col gap-2">
          <h2 className="font-serif text-2xl font-semibold text-foreground sm:text-[28px]">
            Sultan's Heritage Selection
          </h2>
          <p className="font-sans text-sm font-medium text-muted-foreground">
            Showing {visibleCount} exquisite item
            {visibleCount === 1 ? "" : "s"} cooked freshly by our master
            chefs
          </p>
        </div>

        {groupedMenu.length === 0 ? (
          <p className="font-sans text-sm text-muted-foreground">
            No dishes match your search.
          </p>
        ) : (
          groupedMenu.map((group) => (
            <div key={group.category} className="flex flex-col gap-5">
              <h3 className="font-serif text-xl font-semibold text-foreground">
                {group.category}
              </h3>
              <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
                {group.items.map((item) => (
                  <MenuCard key={item.id} item={item} onAdd={handleAdd} />
                ))}
              </div>
            </div>
          ))
        )}
      </section>
    </Layout>
  );
}
